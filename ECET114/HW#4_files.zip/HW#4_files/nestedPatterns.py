#Elvis Nguyen

row = 7
col = 7

for i in range(row):
    for j in range(col):
        print("*", end=" ")
    print("")
    col -= 1