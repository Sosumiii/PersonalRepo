// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.subsystems;

import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.utils.LimelightHelpers;

public class LLVision extends SubsystemBase {

  public LLVision() {}

  /* Gets the x, y ,and angle of tracked apriltag */
  public double[] getApriltagCoordinates(){
    return new double[]{
      LimelightHelpers.getTX(""), 
      LimelightHelpers.getTY(""), 
      LimelightHelpers.getTA("")
      };
  }

  public double[] aimAndRange(){
    double kP = 0.01;

    double angularVel = LimelightHelpers.getTX("") * kP;
    double forwardSpeeds = LimelightHelpers.getTY("") * kP;

    return new double[] {
      angularVel,
      forwardSpeeds
    };


  }

  //@Override
  public void periodic() {
    getApriltagCoordinates();
  }
}
